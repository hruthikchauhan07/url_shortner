# TODO: Implement utility functions here
# Consider functions for:
# - Generating short codes
# - Validating URLs
# - Any other helper functions you need

import random
import string
from urllib.parse import urlparse

def createshort_code(length=6):
    chars = string.ascii_letters+string.digits
    return  "".join(random.choice(chars)for i in range(length))

def ifvalidURL(url):
    try:
        res = urlparse(url)
        return all([res.scheme in ('http','https'), res.netloc])
    except Exception:
        return False

