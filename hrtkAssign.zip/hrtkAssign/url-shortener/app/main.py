from flask import Flask, jsonify, request, redirect
from .utils import createshort_code, ifvalidURL
from .models import save_URL, getURlmapping, clickInc, checkshort_code



app = Flask(__name__)

@app.route('/')
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "URL Shortener API"
    })

@app.route('/api/health')
def api_health():
    return jsonify({
        "status": "ok",
        "message": "URL Shortener API is running"
    })

@app.route('/api/shorten', methods=['POST'])
def shortURL():
    data = request.get_json()
    originalURL = data.get('url')
    if not originalURL or not ifvalidURL(originalURL):
        return jsonify({
            "error": "Invalid of missing URL"
        }),400
    short_code = createshort_code()
    while checkshort_code(short_code):
        short_code = createshort_code()
    save_URL(short_code,originalURL)
    return jsonify({
        "short_code":short_code,
        "original_URL": originalURL
    }), 201
    

@app.route('/<short_code>')
def shortURLredirect(short_code):
    mapping = getURlmapping(short_code)
    if not mapping:
        return jsonify({
            "error": "Short code not found!"
        }),404
    clickInc(short_code)
    return redirect(mapping["url"])


@app.route('/api/stats/<short_code>')
def stats(short_code):
    mapping = getURlmapping(short_code)
    if not mapping:
        return jsonify({
            "error": "Short code not found"
        }),404
    return jsonify({
        "short_code": short_code,
        "original_URL": mapping["url"],
        "clicks": mapping["clicks"],
        "created": mapping["created"]
    })



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)