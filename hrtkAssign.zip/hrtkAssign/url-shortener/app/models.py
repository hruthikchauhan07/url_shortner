# TODO: Implement your data models here
# Consider what data structures you'll need for:
# - Storing URL mappings
# - Tracking click counts
# - Managing URL metadata

import threading
from datetime import datetime

store_URL = {}

lock = threading.Lock()


#this function is used to save the shortURL and it's originality
def save_URL(short_code, originalURL):
    with lock:
        store_URL[short_code]={
            "url":originalURL,
            "clicks":0,
            "created":datetime.utcnow().isoformat()
        }

#function to retrieve mapping of short code
def getURlmapping(short_code):
    with lock:
        return store_URL.get(short_code)

#function for incrementing number of clicks on url
def clickInc(short_code):
    with lock:
        if short_code in store_URL:
            store_URL[short_code]["clicks"]+= 1


#function to check if the current short code exists already
def checkshort_code(short_code):
    with lock:
        return short_code in store_URL